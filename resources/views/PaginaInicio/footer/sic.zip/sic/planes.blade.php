@extends('layouts.includes.inicio') 
@section('content2') 
<div class="full">
	<div class="enlamitad-2">
		<center>
			<div class="card-paginicio card-text-principal">
				<h2 class="card-title card-title-module"><img src="/images/favicon.png" style="margin-right: 15px;margin-bottom: -15px;">¡LOS MEJORES PLANES PARA TI, CLARO QUE SIC!<img src="/images/favicon.png" style="margin-left: 15px; margin-bottom: -15px;"></h2>
			</div>
			<div class="card-paginicio">
				<center>
					<div class="enlamitad">
						<h1 style="padding-top: 20px; margin-bottom: 30px;"><img src="/images/favicon.png" style="margin-right: 15px;margin-bottom: -15px;">PLANES<img src="/images/favicon.png" style="margin-left: 15px; margin-bottom: -15px;"><br><font style="    color: rgb(255, 126, 0);">Planes que tenemos disponibles para ti</font></h1>
						<ul class="planes">
							<li>
								<div class="title-plan">
									<h2>Plan Normal</h2><br>
									<h2>50.000 COP/MES</h2>
								</div>
								<div class="content-plan">
									<p>Este es el plan que disponemos para ti:
										50facturas <br>
										100Cotizaciones <br>
										150 Productos en inventario <br>
										Reportes <br>
									</p>
								</div>
								
							</li>
							<li>
								<div class="title-plan">
									<h2>Plan Pro</h2><br>
									<h2>80.000 COP/MES</h2>
								</div>
								<div class="content-plan">
									<p>Este es el plan que disponemos para ti:
										100facturas <br>
										200Cotizaciones <br>
										500 Productos en inventario <br>
										Reportes <br>
									</p>
								</div>
							</li>
							<li>
								<div class="title-plan">
									<h2>Plan Premium</h2><br>
									<h2>110.000COP/MES</h2>
								</div>
								<div class="content-plan">
									<p>Este es el plan que disponemos para ti:
										50facturas <br>
										100Cotizaciones <br>
										150 Productos en inventario <br>
										Reportes <br>
										1 PAGINA WEB!
									</p>
								</div>
							</li>
						</ul>
						<img src="https://www.winkhosting.com/assets/images/formaspago.png" style="margin-bottom: 50px; margin-top: 20px; width: 100%;">
					</div>
				</center>
			</div>
		</center>
	</div>
</div>
@endsection