@extends('layouts.includes.inicio') 
@section('content2') 
<main>
	<nav class="nav-ocult">
		<button class="btn-menu" data-pushbar-target="pushbar-menu"><i class="fas fa-bars"></i></button>
		<a href="#" class="banner" data-pushbar-target="pushbar-productos">SIC (Siatema Integrado Cotizaciones)</a>
	</nav>
	<div class="section1">
		<center>
			<img src="/images/logo.png" class="logo-presentacion">
			<h4>Software Contable y de Facturación para Pequeñas Empresas
			Miles de Empresas en Colombia están Ganando Tiempo y Tranquilidad con Alegra. Empieza tu mes gratis.</h4>
		</center>
	</div>
	<div class="section1">
		<div class="formulario-empresa">
			<form class="form-control formu-empresa">
				<center><h1 style="margin-bottom: 10px;"><img src="/images/favicon.png" style="margin-right: 5px;margin-bottom: -15px;">CREAR CUENTA<img src="/images/favicon.png" style="margin-left: 5px; margin-bottom: -15px;"></h1></center>
				<label for="txtcorreo">Correo Electronico</label>
				<input type="text" name="txtcorreo" class="">

				<label for="txtcontrasena">Contraseña</label>
				<input type="password" name="txtcontrasena" class="">

				<label for="txtempresa">Nombre de la Empresa</label>
				<input type="text" name="txtempresa" class="">

				<label for="txtcedula">Cedula o NIT:</label>
				<input type="text" name="txtcedula" class="">
				<P>¡Pruebalo totalmente gratis durante 2 meses!</P>

				<input type="submit" name="txtaceptar" value="CREAR EMPRESA">
			</form>
		</div>
	</div>
	<div class="section2">
		<center>
			<div class="enlamitad">
				<h1 style="padding-top: 20px; margin-bottom: 30px;">GESTIONA TU SIC <br><font color="#ff7e00">(Sistema Integrado Contable)</font></h1>
				<ul id="list-services">
					<li><a href="#"><img src="/images/bombilo.png" class="quebusca-img padentro"></a>
						<h2>Productividad</h2>
						<p>Incremente la productividad de sus empleados eliminando procesos manuales repetitivos a través de la integración sistematizada de todas las áreas del negocio.</p>
					</li>
					<li><a href="#"><img src="/images/bombilo.png" class="quebusca-img padentro"></a><h2>Productividad</h2>
						<p>Incremente la productividad de sus empleados eliminando procesos manuales repetitivos a través de la integración sistematizada de todas las áreas del negocio.</p></li>
						<li><a href="#"><img src="/images/bombilo.png" class="quebusca-img padentro"></a><h2>Productividad</h2>
							<p>Incremente la productividad de sus empleados eliminando procesos manuales repetitivos a través de la integración sistematizada de todas las áreas del negocio.</p></li>
							<li><a href="#"><img src="/images/bombilo.png" class="quebusca-img padentro"></a><h2>Productividad</h2>
								<p>Incremente la productividad de sus empleados eliminando procesos manuales repetitivos a través de la integración sistematizada de todas las áreas del negocio.</p></li>
								<li><a href="#"><img src="/images/bombilo.png" class="quebusca-img padentro"></a><h2>Productividad</h2>
									<p>Incremente la productividad de sus empleados eliminando procesos manuales repetitivos a través de la integración sistematizada de todas las áreas del negocio.</p></li>
									<li><a href="#"><img src="/images/bombilo.png" class="quebusca-img padentro"></a><h2>Productividad</h2>
										<p>Incremente la productividad de sus empleados eliminando procesos manuales repetitivos a través de la integración sistematizada de todas las áreas del negocio.</p></li>
									</ul>
								</div>
							</center>
						</main>
						<div style="text-align: center;">
							<p>

							</p>
						</div>

						<!-- Pushbars: Menu -->
						<div data-pushbar-id="pushbar-menu" class="pushbar from_left pushbar-menu">
							<div class="btn-cerrar derecha">
								<button data-pushbar-close><i class="fas fa-times"></i></button>
							</div>
							<nav class="menu">
								<a href="#">inicio</a>
								<a href="#">Nuestros Productos</a>
								<a href="#">Nuestras Tiendas</a>
								<a href="#">Agentes de ventas</a>
								<a href="#">Contacto</a>
							</nav>
						</div>

						<!-- Pushbars: Carrito de Compras -->


						<!-- Pushbars: Productos -->


						<!-- Pushbars: Newsletter -->

					</div>
					<script defer src="https://use.fontawesome.com/releases/v5.3.1/js/all.js"></script>
				</body>
				</html>
				@endsection