@extends('layouts.app')
@section('content')
  <!--Formulario Facturas-->
  <form method="POST" action="{{ route('remisiones.store') }}" style="padding: 2% 3%;    " role="form" class="forms-sample" novalidate id="form-factura" >
    {{ csrf_field() }} 
    <input type="hidden" value="1" name="cotizacion" id="cotizacion_si">
    <div class="row text-right">
      <div class="col-md-5">
        <div class="form-group row">
          <label class="col-sm-4 col-form-label">Cliente <span class="text-danger">*</span></label>
          <div class="col-sm-8">
            <div class="input-group">
              <select class="form-control selectpicker" name="cliente" id="cliente" required="" title="Seleccione" data-live-search="true" data-size="5" onchange="contacto(this.value);">
                @foreach($clientes as $client)
                  <option {{old('cliente')==$client->id?'selected':''}} value="{{$client->id}}">{{$client->nombre}}</option>
                @endforeach
              </select>
                <div class="input-group-append" >
                <span class="input-group-text nopadding">
                  <a class="btn btn-outline-secondary btn-icons" title="Actualizar" onclick="contactos('{{route('contactos.clientes.json')}}', 'cliente');" style="margin-left: 8%;"><i class="fas fa-sync"></i></a>
                </span>
                </div>
            </div>
              <p class="text-left nomargin">
                  <a href="{{route('contactos.create')}}" target="_blanck"><i class="fas fa-plus"></i>
                      Nuevo Contacto
                  </a>
              </p>
          </div>
          <span class="help-block error">
            <strong>{{ $errors->first('cliente') }}</strong>
          </span>
        </div>    
        <div class="form-group row">
          <label class="col-sm-4  col-form-label">Observaciones <br> <small>No visible en la remisión</small></label>
          <div class="col-sm-8">
            <textarea  class="form-control form-control-sm min_max_100" name="observaciones"></textarea>
          </div>
        </div>
        <div class="form-group row">
            <label class="col-sm-4 col-form-label">Notas de la remisión<a><i data-tippy-content="Notas visibles en la remision" class="icono far fa-question-circle"></i></a></label>
            <div class="col-sm-8">
              <textarea  class="form-control form-control-sm min_max_100" name="notas"></textarea>
            </div>
          </div>
        <div class="form-group row">
          <label class="col-sm-4 col-form-label">Bodega <span class="text-danger">*</span></label>
          <div class="col-sm-8">
            <select name="bodega" id="bodega" class="form-control"  required="">
              @foreach($bodegas as $bodega)  
                <option value="{{$bodega->id}}">{{$bodega->bodega}}</option>
              @endforeach
            </select>
          </div>
        </div>
      </div>

      <div class="col-md-5 offset-md-2">
        <div class="form-group row" style="text-align: center;">
          <label class="col-sm-12 col-form-label" > <h4><b class="text-primary">No. </b> {{$nro->remision}}</h4></label>
        </div>
        <div class="form-group row">
          <label class="col-sm-4 col-form-label">Fecha <span class="text-danger">*</span></label>
          <div class="col-sm-8">
            <input type="text" class="form-control datepicker"  id="fecha" value="{{date('d-m-Y')}}" name="fecha" disabled=""  > 
          </div>
        </div> 

        <div class="form-group row">
          <label class="col-sm-4 col-form-label">Vencimiento <span class="text-danger">*</span></label>
          <div class="col-sm-8">
            <input type="text" class="form-control" id="vencimiento" value="{{date('d-m-Y')}}" name="vencimiento" disabled="">
          </div>
        </div>

        <div class="form-group row">
          <label class="col-sm-4 col-form-label">Vendedor</label>
          <div class="col-sm-8">
            <select name="vendedor" id="vendedor" class="form-control selectpicker " title="Seleccione" data-live-search="true" data-size="5">
              @foreach($vendedores as $vendedor)  
                <option value="{{$vendedor->id}}">{{$vendedor->nombre}}</option>
              @endforeach
            </select>
          </div> 
        </div>

        <div class="form-group row">
          <label class="col-sm-4 col-form-label">Lista de Precios <a><i data-tippy-content="Lista de precios asociada a la remisión, puedes agregar nuevas listas de precio haciendo <a href='#'>clíck aquí</a>" class="icono far fa-question-circle"></i></a></label>
          <div class="col-sm-8">
            <select name="lista_precios" id="lista_precios" class="form-control selectpicker">
              @foreach($listas as $lista)  
                <option value="{{$lista->id}}">{{$lista->nombre()}} </option>
              @endforeach
            </select>
          </div>
        </div>
        <div class="form-group row">
          <label class="col-sm-4 col-form-label">Tipo de documento <span class="text-danger">*</span><a><i data-tippy-content="Elige el nombre que desees dar a tus documentos" class="icono far fa-question-circle"></i></a></label>
          <div class="col-sm-8">
            <select name="documento" id="documento" class="form-control selectpicker " data-live-search="true" data-size="5" required="">
              <option value="1">Remisión</option>
              <option value="2">Orden de Servicio</option>
            </select>
          </div>
        </div>
      </div>
      <small>Los campos marcados con <span class="text-danger">*</span> son obligatorios</small>
      
    </div>

    <hr>
    <!-- Desgloce -->
    <div class="row">
      <div class="col-md-12 fact-table">
        <table class="table table-striped table-sm" id="table-form" width="100%">
          <thead class="thead-dark">
            <tr>
              <th width="29%">Ítem</th>
              <th width="10%">Referencia</th>
              <th width="12%">Precio</th>
              <th width="5%">Desc %</th>
              <th width="12%">Impuesto</th>
              <th width="13%">Descripción</th>
              <th width="7%">Cantidad</th>
              <th width="10%">Total</th>
              <th width="2%"></th>
            </tr>
          </thead>
            <tbody>
              <tr id="1">
                <td  class="no-padding">                           
                  <select class="form-control form-control-sm selectpicker no-padding"  title="Seleccione" data-live-search="true" data-size="5" name="item[]" id="item1" onchange="rellenar(1, this.value);" required="">
                  @foreach($inventario as $item)
                  <option value="{{$item->id}}">{{$item->producto}} - ({{$item->ref}})</option>
                  @endforeach
                  </select>
                </td>
                <td>
                  <input type="text" class="form-control form-control-sm" id="ref1" name="ref[]" placeholder="Referencia" required="">
                </td>
                <td class="monetario">
                  <input type="number" class="form-control form-control-sm" id="precio1" name="precio[]" placeholder="Precio Unitario" onkeyup="total(1)" required="" maxlength="24" min="0">
                </td>
                <td>
                  <input type="text" class="form-control form-control-sm nro" id="desc1" name="desc[]" placeholder="%" onkeyup="total(1)" >
                </td>
                <td>
                <select class="form-control form-control-sm selectpicker" name="impuesto[]" id="impuesto1" title="Impuesto" onchange="totalall();" required="">
                  @foreach($impuestos as $impuesto)
                    <option value="{{$impuesto->id}}" porc="{{$impuesto->porcentaje}}">{{$impuesto->nombre}} - {{$impuesto->porcentaje}}%</option>
                  @endforeach
                </select>
              </td>
              <td  style="padding-top: 1% !important;">                           
                <textarea  class="form-control form-control-sm" id="descripcion1" name="descripcion[]" placeholder="Descripción" ></textarea>
              </td>
              <td>
                <input type="number" class="form-control form-control-sm" id="cant1" name="cant[]" placeholder="Cantidad" onchange="total(1);" min="1" required="" maxlength="24">
                <p class="text-danger nomargin" id="pcant1"></p>
              </td>
              <td>
                <input type="text" class="form-control form-control-sm text-right" id="total1" value="0" disabled="">
              </td>
              <td>
                <button type="button" class="btn btn-outline-secondary btn-icons" onclick="Eliminar(1);">X</button>
              </td>
            </tr>
          </tbody>
        </table>
        
        <div class="alert alert-danger" style="display: none;" id="error-items"></div>
      </div>
    </div>
    <button class="btn btn-outline-primary" onclick="createRow();" type="button" style="margin-top: 5%">Agregar línea</button>

    <!-- Totales -->
    <div class="row" style="margin-top: 10%;">
      <div class="col-md-4 offset-md-8">
        <table class="text-right widthtotal" id="totales">
          <tr>
            <td width="40%">Subtotal</td>
            <td>{{Auth::user()->empresa()->moneda}} <span id="subtotal">0</span></td>
          </tr>
          <tr>
            <td>Descuento</td><td id="descuento">{{Auth::user()->empresa()->moneda}} 0</td>
          </tr>
          <tr>
            <td>Subtotal</td>
            <td>{{Auth::user()->empresa()->moneda}} <span id="subsub">0</span></td>
          </tr>
        </table>
        <hr>
        <table class="text-right widthtotal" style="font-size: 24px !important;">
          <tr>
            <td width="40%">TOTAL</td>
            <td>{{Auth::user()->empresa()->moneda}} <span id="total">0</span></td>
          </tr>
        </table>
      </div>
    </div>
    <hr>
    <!--Botones Finales -->
    <div class="row" >
      <div class="col-md-12 text-right" style="padding-top: 1%;">
        <a href="{{route('facturas.index')}}" class="btn btn-outline-secondary">Cancelar</a>
        <button type="submit" class="btn btn-success">Guardar</button>
      </div>
    </div>
  </form>
  <input type="hidden" id="impuestos" value="{{json_encode($impuestos)}}">
  <input type="hidden" id="allproductos" value="{{json_encode($inventario)}}">
  <input type="hidden" id="url" value="{{url('/')}}">
  <input type="hidden" id="jsonproduc" value="{{route('inventario.all')}}">
  <input type="hidden" id="simbolo" value="{{Auth::user()->empresa()->moneda}}">

@endsection
