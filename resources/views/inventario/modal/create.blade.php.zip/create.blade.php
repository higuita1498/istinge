	<form method="POST" action="{{ route('inventario.storeback') }}" style="padding: 2% 3%;" role="form" class="forms-sample" novalidate id="form-inventario" enctype="multipart/form-data">
  		{{ csrf_field() }}
  		<div class="row"> 
			<div class="form-group col-md-4">
	  			<label class="control-label">Nombre del Producto <span class="text-danger">*</span></label>
				<input type="text" class="form-control" name="producto" id="producto" required="" maxlength="200" value="{{old('producto')}}">
				<span class="help-block error">
		        	<strong>{{ $errors->first('producto') }}</strong>
		        </span>
		         <p class="text-left nomargin"> 
              <a href="{{route('contactos.create')}}" data-toggle="modal" data-target="#myModal"><i class="fas fa-plus"></i> Nuevo Contacto</a></p>
			</div>
			<div class="form-group col-md-4">
	  			<label class="control-label">Referencia <span class="text-danger">*</span></label>
				<input type="text" class="form-control" name="ref" id="ref" maxlength="200" value="{{old('ref')}}">
				<span class="help-block error">
		        	<strong>{{ $errors->first('ref') }}</strong>
		        </span>
			</div>
			<div class="form-group col-md-4">
	  			<label class="control-label">Categoria <span class="text-danger">*</span><a><i data-tippy-content="Selecciona la categoría en la que se registrarán los valores por venta del ítem" class="icono far fa-question-circle"></i></a></label>
	  			<select class="form-control selectpicker" name="categoria" id="categoria" required="" title="Seleccione" data-live-search="true" data-size="5">
	  				@foreach($categorias as $categoria)
                  		@if($categoria->estatus==1)
                            <option {{old('categoria')==$categoria->id?'selected':( Auth::user()->empresa()->categoria_default==$categoria->id?'selected':'')}} {{$categoria->nombre == 'Activos' ? 'selected' : ''}} value="{{$categoria->id}}">{{$categoria->nombre}}</option>
                        @endif
                        @foreach($categoria->hijos(true) as $categoria1)
                  			@if($categoria1->estatus==1)
	                  			<option {{old('categoria')==$categoria1->id?'selected':( Auth::user()->empresa()->categoria_default==$categoria1->id?'selected':'')}} value="{{$categoria1->id}}">{{$categoria1->nombre}}</option>
	                  		@endif
	                  		@foreach($categoria1->hijos(true) as $categoria2)
	                  			@if($categoria2->estatus==1)
		                  			<option {{old('categoria')==$categoria2->id?'selected':( Auth::user()->empresa()->categoria_default==$categoria2->id?'selected':'')}} value="{{$categoria2->id}}">{{$categoria2->nombre}}</option>
		                  		@endif
		                  		@foreach($categoria2->hijos(true) as $categoria3)
		                  			@if($categoria3->estatus==1)
			                  			<option {{old('categoria')==$categoria3->id?'selected':( Auth::user()->empresa()->categoria_default==$categoria3->id?'selected':'')}} value="{{$categoria3->id}}">{{$categoria3->nombre}}</option>
			                  		@endif
			                  		@foreach($categoria3->hijos(true) as $categoria4)
			                  			@if($categoria4->estatus==1)
				                  			<option {{old('categoria')==$categoria4->id?'selected':( Auth::user()->empresa()->categoria_default==$categoria4->id?'selected':'')}} value="{{$categoria4->id}}">{{$categoria4->nombre}}</option>
				                  		@endif

			                  		@endforeach

		                  		@endforeach

	                  		@endforeach

                  		@endforeach


	  				@endforeach
                </select>
				<span class="help-block error">
		        	<strong>{{ $errors->first('categoria') }}</strong>
		        </span>
			</div>
  		</div>
  		<div class="row">
			<div class="form-group col-md-5">
	  			<label class="control-label">Impuesto <span class="text-danger">*</span></label>
	  			<select class="form-control selectpicker" name="impuesto" id="impuesto" required="" title="Seleccione">
	  				@foreach($impuestos as $impuesto)
                  		<option {{old('impuesto')==$impuesto->id?'selected':''}} value="{{$impuesto->id}}">{{$impuesto->nombre}} - {{$impuesto->porcentaje}} %</option>
	  				@endforeach
                </select>
				<span class="help-block error">
					<strong>{{ $errors->first('impuesto') }}</strong>
				</span>
			</div>
  			<div class="form-group col-md-7 ">
	  			<div class="row">
	  				<div class="col-md-6 monetario">
	  					<label class="control-label">Precio de Venta <span class="text-danger">*</span></label>
						<input type="number" class="form-control " id="precio" name="precio" required="" maxlength="24" value="{{old('precio')}}" placeholder="{{Auth::user()->empresa()->moneda}}" min="0" >
						<span class="help-block error">
				        	<strong>{{ $errors->first('precio') }}</strong>
				        </span>
					    <span class="litte">Use el punto (.) para colocar decimales</span>
	  				</div>
	  				<div class="col-md-6" style="padding-top: 6%;padding-left: 0;"><button type="button" class="btn btn-link " style="padding-left: 0;" onclick="agregarlista_precios();" @if(json_encode($listas)=='[]') title="Usted no tiene lista de precios registrada" @endif><i class="fas fa-plus"></i> Agregar otra lista de precio</button></div>
	  			</div>
	  			<div class="row" id="lista_precios_inventario">
	  				<div class="col-md-12">
	  					<table id="table_lista_precios">
	  						<tbody>
	  						</tbody>
	  					</table>
	  				</div>
	  			</div>

			</div>
  		</div>
  		<div class="row">
			<div class="form-group col-md-8">
	  			<label class="control-label" for="email">Descripción</label>
				<input type="text" class="form-control" id="email" name="descripcion" maxlength="255"  value="{{old('descripcion')}}">
				<div class="help-block error with-errors"></div>
				<span class="help-block error">
					<strong>{{ $errors->first('descripcion') }}</strong>
				</span>
			</div>

  			<div class="form-group col-md-4">
	  			<label class="control-label"><button type="button" class="btn btn-link btn-fw" id="button_show_div_img">Imagen (Opcional)</button></label>
	  			<div style="display: none;" id="div_imagen">
	  				<input type="file" class="dropify" name="imagen" />
					<span class="help-block error">
			        	<strong>{{ $errors->first('imagen') }}</strong>
			        </span>
	  			</div>
			</div>
			
			
  		</div>
  		@if(Auth::user()->empresa()->carrito==1)
  		<div class="row" >
	  		<div class="col-md-12">
	  			<div class="form-group row">
					<label for="publico" class="col-md-3 col-form-label">¿Estara el producto público en la web? <a><i data-tippy-content="Si eliges 'si' automaticamente al presionar guardar el producto irá a tu tienda online" class="icono far fa-question-circle"></i></a></label>
				    <div class="col-md-2">
				    	<div class="row">
							<div class="col-sm-6">
							<div class="form-radio">
								<label class="form-check-label">
								<input type="radio" class="form-check-input" name="publico" id="publico1" value="1" > Si
								<i class="input-helper"></i></label>
							</div>
						</div>
						<div class="col-sm-6">
							<div class="form-radio">
								<label class="form-check-label">
								<input type="radio" class="form-check-input" name="publico" id="publico" value="0" checked=""> No
								<i class="input-helper"></i></label>
							</div>
						</div>
						</div>
				    </div>
				
				</div>
			</div>
		</div>	

		<div class="row">
	  		<div class="col-md-12 form-group">
	  			Imagenes extras
	  			<input type="file" class="form-control" name="imagenes_extra[]" multiple/>
	  		</div>			
		</div>	
		@endif	

  		<div class="row" >

			<div class="form-group col-md-2">
	  			<label class="control-label">¿Producto Inventariable? <a><i data-tippy-content="Son productos que tienen cantidad y un precio unitario" class="icono far fa-question-circle"></i></a></label>
				<div class="row">
					<div class="col-sm-6">
					<div class="form-radio">
						<label class="form-check-label">
						<input type="radio" class="form-check-input" name="tipo_producto" id="tipo_producto1" value="2" checked=""> No
						<i class="input-helper"></i></label>
					</div>
				</div>
				<div class="col-sm-6">
					<div class="form-radio">
						<label class="form-check-label">
						<input type="radio" class="form-check-input" name="tipo_producto" id="tipo_producto2" value="1" @if(old('tipo_producto')==1) checked="" @endif> Si
						<i class="input-helper"></i></label>
					</div>
				</div>
				</div>
				<span class="help-block error">
					<strong>{{ $errors->first('tipo_producto') }}</strong>
				</span>
			</div>

  			<div id="inventariable" class="col-md-10" style="@if(old('tipo_producto')) display: block; @else display: none; @endif  ">
				<div class="row">
					<div class="form-group col-md-4" >
						<label class="control-label">Unidad de medida</label>
						<select class="form-control selectpicker" name="unidad" id="unidad" required="" title="Seleccione" data-live-search="true" data-size="5">
			  				@foreach($medidas2 as $medida)
			  					<optgroup label="{{$medida->medida}}">
	    							@foreach($unidades2 as $unidad)
	    							@if($medida->id==$unidad->tipo)
	    								<option {{old('unidad')==$unidad->id?'selected':''}} value="{{$unidad->id}}">{{$unidad->unidad}}</option>
	    							@endif
	    							@endforeach
 								 </optgroup>

		                  		
			  				@endforeach
		                </select>
						<strong>{{ $errors->first('unidad') }}</strong>
					</div>
					<div class="form-group col-md-4 monetario" >
						<label class="control-label">Costo unidad</label>
						<input type="number" class="form-control" name="costo_unidad" id="costo_unidad" required="" maxlength="24" min="0" value="{{old('costo_unidad')}}" placeholder="{{Auth::user()->empresa()->moneda}}">
						<span class="help-block error">
						<strong>{{ $errors->first('costo_unidad') }}</strong>
						</span>
						<span class="litte">Use el punto (.) para colocar decimales</span>
					</div>
				</div>
	  			<div class="row" id="bodega_inventario">
	  				<div class="col-md-8 form-group">
	  					<table id="table_bodega">
	  						<tbody>

	  						</tbody>
	  					</table>
	  				</div>
	  			</div>
	  			<button type="button" class="btn btn-link" onclick="agregarbodega_inventario();" style="padding-top: 0;"><i class="fas fa-plus"></i> Agregar en otra bodega</button>
  			</div>
            <div class="form-group col-md-2">
                <label class="control-label">Asignar a una lista</label>
                <select name="list" class="form-control">
                    <option value="0" selected>Ninguna</option>
                    <option value="1">Más vendidos</option>
                    <option value="2">Recientes</option>
                    <option value="3">Oferta</option>
                </select>
            </div>
  		</div>

        <div class="row">

        </div>

  		<div class="row">
  			@php  $search=array(); @endphp
  			 @foreach($extras2 as $campo)
                <div class="form-group col-md-4" >
					<label class="control-label">{{$campo->nombre}} @if($campo->tipo==1) <span class="text-danger">*</span> @endif</label>
					<input type="text" class="form-control" name="ext_{{$campo->campo}}" id="{{$campo->campo}}-autocomplete" @if($campo->tipo==1) required="" @endif  @if($campo->varchar) maxlength="{{$campo->varchar}}" @endif   value="{{$campo->default}}">
				<p><small>{{$campo->descripcion}}</small></p>
				</div>
				@if($campo->autocompletar==1)
                	@php $search[]=$campo->campo; @endphp 
					<input type="hidden" id="search{{$campo->campo}}" value="{{json_encode($campo->records())}}">
				@endif
            @endforeach

           @if ($search) <input type="hidden" id="camposextra" value="{{json_encode($search)}}"> @endif
  		</div>
  		<small>Los campos marcados con <span class="text-danger">*</span> son obligatorios</small>
  		<hr>
  		<div class="row" style="text-align: right;">
  			<div class="col-md-12">
				<a href="{{route('inventario.index')}}" class="btn btn-outline-light" >Cancelar</a>
  				<button type="submit" class="btn btn-success">Guardar</button>
  			</div>
  		</div>
  		
  	</form>
  	<input type="hidden" id="json_precios" value="{{json_encode($listas)}}">
  	<input type="hidden" id="json_bodegas" value="{{json_encode($bodegas)}}">	
  	
  	 
   <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title"></h4>
        </div>
        <div class="modal-body">
          	<form method="POST" action="{{ route('contactos.store') }}" style="padding: 2% 3%;" role="form" class="forms-sample" novalidate id="form-contacto">
  		{{ csrf_field() }}
  		<div class="row">
  			<div class="form-group col-md-3">
	  			<label class="control-label">Tipo de Identificación <span class="text-danger">*</span></label>
	  			<select class="form-control selectpicker" name="tip_iden" id="tip_iden" required="" title="Seleccione">
	  				@foreach($identificaciones as $identificacion)
                  		<option {{old('tip_iden')==$identificacion->id?'selected':''}} value="{{$identificacion->id}}" title="{{$identificacion->mini()}}">{{$identificacion->identificacion}}</option>
	  				@endforeach
                </select>
				<span class="help-block error">
		        	<strong>{{ $errors->first('tip_iden') }}</strong>
		        </span>
			</div>
			<div class="form-group col-md-3">
	  			<label class="control-label">Identificación <span class="text-danger">*</span><a><i data-tippy-content="Identificación de la persona" class="icono far fa-question-circle"></i></a></label>
				<input type="text" class="form-control" name="nit" id="nit" required="" maxlength="20" value="{{old('nit')}}">
				<span class="help-block error">
					<strong>{{ $errors->first('nit') }}</strong>
				</span>
			</div>

			<div class="form-group col-md-6">
	  			<label class="control-label">Nombre <span class="text-danger">*</span></label>
				<input type="text" class="form-control" name="nombre" id="nombre" required="" maxlength="200" value="{{old('nombre')}}">
				<span class="help-block error">
		        	<strong>{{ $errors->first('nombre') }}</strong>
		        </span>
			</div>
  		</div> 
  		<div class="row">
  			<div class="form-group col-md-5">
	  			<label class="control-label">Dirección </label>
	  			<textarea class="form-control" name="direccion" >{{old('direccion')}}</textarea>
				<span class="help-block error">
					<strong>{{ $errors->first('direccion') }}</strong>
				</span>
			</div>
			<div class="form-group col-md-3">
	  			<label class="control-label">Ciudad</label>
				<input type="text" class="form-control" id="ciudad" name="ciudad" maxlength="200"  value="{{old('ciudad')}}">
				<span class="help-block error">
					<strong>{{ $errors->first('ciudad') }}</strong>
				</span>
			</div>
			<div class="form-group col-md-4">
	  			<label class="control-label" for="email">Correo Electrónico</label>
				<input type="email" class="form-control" id="email" name="email" data-error="Dirección de correo electrónico invalida" maxlength="100"  value="{{old('email')}}">
				<div class="help-block error with-errors"></div>
				<span class="help-block error">
					<strong>{{ $errors->first('email') }}</strong>
				</span>
			</div>
			


  		</div>
  		<div class="row">
  			<div class="form-group col-md-3">
	  			<label class="control-label">Teléfono  <span class="text-danger">*</span></label>
	  			<div class="row">
	  				<div class="col-md-4 nopadding ">
	  					<select class="form-control selectpicker prefijo" name="pref1" id="pref1" required="" title="Seleccione" data-size="5" data-live-search="true">
			  				@foreach($prefijos as $prefijo)
		                  		<option @if(old('pref1')) {{old('pref1')==$prefijo->phone_code?'selected':''}} @else {{'+'.$prefijo->phone_code==Auth::user()->empresa()->codigo?'selected':''}}  @endif

		                  		 	data-icon="flag-icon flag-icon-{{strtolower($prefijo->iso2)}}"

		                  		 value="+{{$prefijo->phone_code}}" title="+{{$prefijo->phone_code}}" data-subtext="+{{$prefijo->phone_code}}">{{$prefijo->nombre}}</option>
			  				@endforeach
		                </select>

				
	  				</div>
	  				<div class="col-md-8" style="padding-left:0;">
	  					<input type="text" class="form-control" id="telefono1" name="telefono1" required="" maxlength="15" value="{{old('telefono1')}}">
	  				</div>
	  			</div>
				<span class="help-block error">
		        	<strong>{{ $errors->first('telefono1') }}</strong>
		        </span>
			</div>
  			<div class="form-group col-md-3">
	  			<label class="control-label">Teléfono 2</label>
  				<div class="row">
  					<div class="col-md-4 nopadding ">
	  					<select class="form-control selectpicker prefijo" name="pref2" id="pref2" title="Seleccione" data-size="5" data-live-search="true">
			  				@foreach($prefijos as $prefijo)
		                  		<option @if(old('pref2')) {{old('pref2')==$prefijo->phone_code?'selected':''}} @else {{'+'.$prefijo->phone_code==Auth::user()->empresa()->codigo?'selected':''}}  @endif

		                  		 	data-icon="flag-icon flag-icon-{{strtolower($prefijo->iso2)}}"

		                  		 value="+{{$prefijo->phone_code}}" title="+{{$prefijo->phone_code}}" data-subtext="+{{$prefijo->phone_code}}">{{$prefijo->nombre}}</option>
			  				@endforeach
		                </select>
	  				</div>
	  				<div class="col-md-8" style="padding-left:0;">
	  					<input type="text" class="form-control" id="telefono2" name="telefono2" maxlength="15" value="{{old('telefono2')}}">
	  				</div>
  				</div>
				<span class="help-block error">
		        	<strong>{{ $errors->first('telefono2') }}</strong>
		        </span>
			</div>
			<div class="form-group col-md-3">
	  			<label class="control-label">Fax</label>
					<div class="row">
						<div class="col-md-4 nopadding ">
		  					<select class="form-control selectpicker prefijo" name="preffax" id="preffax" title="Seleccione" data-size="5" data-live-search="true">
				  				@foreach($prefijos as $prefijo)
			                  		<option @if(old('preffax')) {{old('preffax')==$prefijo->phone_code?'selected':''}} @else {{'+'.$prefijo->phone_code==Auth::user()->empresa()->codigo?'selected':''}}  @endif

			                  		 	data-icon="flag-icon flag-icon-{{strtolower($prefijo->iso2)}}"

			                  		 value="+{{$prefijo->phone_code}}" title="+{{$prefijo->phone_code}}" data-subtext="+{{$prefijo->phone_code}}">{{$prefijo->nombre}}</option>
				  				@endforeach
			                </select>
		  				</div>
		  				<div class="col-md-8" style="padding-left:0;">
		  					<input type="text" class="form-control" id="fax" name="fax"  maxlength="15" value="{{old('fax')}}">
		  				</div>
					</div>
					<span class="help-block error">
			        	<strong>{{ $errors->first('fax') }}</strong>
			        </span>
			</div>
			<div class="form-group col-md-3">
	  			<label class="control-label">Celular</label>
	  			<div class="row">
	  				<div class="col-md-4 nopadding ">
	  					<select class="form-control selectpicker prefijo" name="prefcelular" id="prefcelular" title="Seleccione" data-size="5" data-live-search="true">
			  				@foreach($prefijos as $prefijo)
		                  		<option @if(old('prefcelular')) {{old('prefcelular')==$prefijo->phone_code?'selected':''}} @else {{'+'.$prefijo->phone_code==Auth::user()->empresa()->codigo?'selected':''}}  @endif

		                  		 	data-icon="flag-icon flag-icon-{{strtolower($prefijo->iso2)}}"

		                  		 value="+{{$prefijo->phone_code}}" title="+{{$prefijo->phone_code}}" data-subtext="+{{$prefijo->phone_code}}">{{$prefijo->nombre}}</option>
			  				@endforeach
		                </select>
	  				</div>
	  				<div class="col-md-8" style="padding-left:0;">
	  					<input type="text" class="form-control" id="celular" name="celular" maxlength="15" value="{{old('celular')}}">
	  				</div>
	  			</div>
				
				<span class="help-block error">
		        	<strong>{{ $errors->first('celular') }}</strong>
		        </span>
			</div>
			
			
			
  		</div>
  		<div class="row">
			<div class="form-group col-md-3">
	  			<label class="control-label">Tipo de Contacto  <span class="text-danger">*</span></label>
				<div class="form-check form-check-flat">
                    <label class="form-check-label">
                      <input type="checkbox" class="form-check-input" name="contacto[]" value="0"> Cliente
                    <i class="input-helper"></i></label>
                  </div>
                  <div class="form-check form-check-flat">
                    <label class="form-check-label">
                      <input type="checkbox" class="form-check-input" name="contacto[]" value="1" > Proveedor
                    <i class="input-helper"></i></label>
                  </div>
                  <span class="help-block error">
					<strong>{{ $errors->first('contacto') }}</strong>
				</span>
			</div>

  			<div class="form-group col-md-3">
	  			<label class="control-label">Tipo de Empresa <span class="text-danger">*</span><a><i data-tippy-content="Tipo empresa a la que pertenece el contacto" class="icono far fa-question-circle"></i></a></label>
	  			<select class="form-control selectpicker" name="tipo_empresa" id="tipo_empresa" required="" title="Seleccione" data-live-search="true" data-size="5">
	  				@foreach($tipos_empresa as $tipo_empresa)
                  		<option {{old('tipo_empresa')==$tipo_empresa->id?'selected':''}} value="{{$tipo_empresa->id}}">{{$tipo_empresa->nombre}}</option>
	  				@endforeach
                </select>
                <p class="text-left nomargin"> <a href="{{route('tiposempresa.create')}}" target="_blanck"><i class="fas fa-plus"></i> Nuevo Tipo de Empresa</a></p>
				<span class="help-block error">
		        	<strong>{{ $errors->first('tipo_empresa') }}</strong>
		        </span>
			</div>

  			<div class="form-group col-md-3">
  				<label class="control-label">Lista de Precios <a><i data-tippy-content="Lista de precios que desee asociar a este contacto" class="icono far fa-question-circle"></i></a></label>
  				<select class="form-control selectpicker" name="lista_precio" id="lista_precio" title="Seleccione" data-size="5">
  					
	  				@foreach($listas as $lista)
                  		<option {{old('lista_precio')==$lista->id?'selected':''}} value="{{$lista->id}}">{{$lista->nombre()}}</option>
	  				@endforeach
                </select>
  			</div>
  			<div class="form-group col-md-3">
  				<label class="control-label">Vendedor <a><i data-tippy-content="Vendedor que desee asociar a este contacto" class="icono far fa-question-circle"></i></a></label>
  				<select class="form-control selectpicker" name="vendedor" id="vendedor" title="Seleccione" data-live-search="true" data-size="5">
	  				@foreach($vendedores as $vendedor)
                  		<option {{old('vendedor')==$vendedor->id?'selected':''}} value="{{$vendedor->id}}">{{$vendedor->nombre}}</option>
	  				@endforeach
                </select>
  			</div>	
  		</div>
  		<div class="row">
  			<div class="form-group col-md-12">
	  			<label class="control-label">Observaciones</label>

	  			<textarea class="form-control" name="observaciones" >{{old('observaciones')}}</textarea>
				<span class="help-block error">
					<strong>{{ $errors->first('observaciones') }}</strong>
				</span>
			</div>
  		</div>
		<small>Los campos marcados con <span class="text-danger">*</span> son obligatorios</small>
		<div class="row" style="margin-top: 2%;">
  			<div class="col-md-12 fact-table">

				<h4 class="card-title">Personas Asociadas</h4>
                <table class="table table-sm table-striped" id="table-form-contacto" width="100%">
                	<thead class="thead-dark"> 
                		<tr>
							<th width="27%">Nombre	y Apellido</th>
							<th width="28%">Correo Electrónico</th>
							<th width="15%">Teléfono</th>
							<th width="15%">Celular</th>
							<th width="10%">Enviar Notificaciones <a><i data-tippy-content="Marque 'si' cuando desee que esta persona reciba correos con facturas disponibles o vencidas"  class="icono far fa-question-circle"></i></a></th>
							<th width="5%"></th>
                		</tr>
                	</thead>
                	<tbody>
                	</tbody>

                </table>
                <button class="btn btn-outline-primary" onclick="createRowContato();" type="button" >Asociar Persona</button><a><i data-tippy-content="En caso de ser una empresa, personas pertenecientes" class="icono far fa-question-circle"></a></i>
                
            </div>
        </div>    
  		<hr>
  		<div class="row" style="text-align: right;">
  			<div class="col-md-12">
				<a href="{{route('empresas.index')}}" class="btn btn-outline-light" >Cancelar</a>
  				<button type="submit" class="btn btn-success">Guardar</button>
  			</div>
  		</div>

  	</form>
  	<input type="hidden" id="json_precios" value="{{json_encode($listas2)}}">
  	<input type="hidden" id="json_bodegas" value="{{json_encode($bodegas2)}}">

    <script>

        setTimeout(function () {
            $('#inventariable').show();
            $('#precio').removeAttr('required');
            $('#precio_unid').attr('required', '');
            $('#unidad').attr('required', '');
            $('#nro_unid').attr('required', '');
            agregarbodega_inventario();
            $("#form-inventario").validate('destroy');
            form_inventario();
            clearTimeout(this);
        }, 2000);


    </script>
