<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title>Demystifying Email Design</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
</head>
<body style="margin: 0; padding: 0;">
<table border="0" cellpadding="0" cellspacing="0" width="100%">
    <tr>
        <td style="padding: 10px 0 30px 0;">
            <table align="center" border="0" cellpadding="0" cellspacing="0" width="600" style="border: 1px solid #cccccc; border-collapse: collapse;">
                <tr>
                    <td align="center" bgcolor="#70bbd9" style="padding: 40px 0 30px 0; color: #153643; font-size: 28px; font-weight: bold; font-family: Arial, sans-serif;">
                        <h3>
                            {{Auth::user()->empresa()->nombre}}
                        </h3>
                    </td>
                </tr>
                <tr>
                    <td bgcolor="#ffffff" style="padding: 40px 30px 40px 30px;">
                        <table border="0" cellpadding="0" cellspacing="0" width="100%">
                            <tr>
                                <td style="color: #153643; font-family: Arial, sans-serif; font-size: 24px;">
                                    <p style="text-align: justify;">Estimado</p>
                                    <p style="text-align: justify;">{{$cliente}}</p>
                                    <p style="text-align: justify;">Cordial saludo,</p>
                                    <p style="text-align: justify;"><b> {{Auth::user()->empresa()->nombre}}, </b> facturador electrónico, mediante resolución de numeración DIAN 18763003041181 hace entrega del documento electrónico (FACTURA) número: <b> {{$factura->codigo}} </b>, con fecha de emisión <b> {{date('d-m-Y', strtotime($factura->fecha))}} </b> por un valor total de $ <b> {{$total}} </b></p>
                                    <button> Ver Factura</button>
                                    <br>
                                    <p>Dando cumplimiento al Decreto 2242 de 2015, si pasados tres (3) días hábiles siguientes a la recepción de la factura, y aún no ha sido rechazada, el sistema la dará por aceptada.</p>
                                </td>
                            </tr>
                            <tr>

                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td bgcolor="#ee4c50" style="padding: 30px 30px 30px 30px;">
                        <table border="0" cellpadding="0" cellspacing="0" width="100%">
                            <tr>
                                <td style="color: #ffffff; font-family: Arial, sans-serif; font-size: 14px;" width="75%">
                                    &reg; {{Auth::user()->empresa()->nombre}} 2020<br/>
                                    <a href="#" style="color: #ffffff;"><font color="#ffffff">No responder</font></a> a este correo
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
</body>
</html>
