@extends('layouts.app')
@section('content')
    @if(!empty($_GET['pro']))
        @php($new = \App\Model\Inventario\Inventario::where('id', htmlspecialchars($_GET['pro']))->get())
        <input type="hidden" id="impuestosId" value="{{$new[0]['id_impuesto']}}">
    @endif

  <form method="POST" action="{{ route('facturasp.store') }}" style="padding: 2% 3%;    " role="form" class="forms-sample" novalidate id="form-factura" >
      {{ csrf_field() }}
    <input type="hidden" value="1" name="cotizacion" id="cotizacion_si">
    <input type="hidden" value="1" name="orden_si" id="orden_si">
    <input type="hidden" value="1" name="fact_prov" id="fact_prov">
    
    <div class="row text-right">
      <div class="col-md-5">
        <div class="form-group row">
          <label class="col-sm-4 col-form-label">Productor <span class="text-danger">*</span></label>
          <div class="col-sm-8">
            <div class="input-group">
              <select class="form-control selectpicker" name="proveedor" id="cliente" required="" title="Seleccione" data-live-search="true" data-size="5" onchange="contacto(this.value);">
                @foreach($clientes as $client)
                  <option {{old('productor')==$client->id?'selected':''}} {{$proveedor==$client->id?'selected':''}} value="{{$client->id}}">{{$client->nombre}} - {{$client->nit}}</option>
                @endforeach
              </select>
            </div>
            <p class="text-left nomargin">
              <a href="{{route('contactos.create')}}" data-toggle="modal" data-target="#myModal"><i class="fas fa-plus"></i> Nuevo Contacto</a></p>
          </div>
          <span class="help-block error">
            <strong>{{ $errors->first('productor') }}</strong>
          </span>
        </div>    
        <div class="form-group row">
          <label class="col-sm-4  col-form-label">Observaciones <br> <small>(No visible en el documento impreso)</small></label>
          <div class="col-sm-8">
            <textarea  class="form-control form-control-sm min_max_100" name="observaciones">{{old('observaciones')}}</textarea>
          </div>
        </div>
        <div class="form-group row">
          <label class="col-sm-4  col-form-label">Notas <br> <small>(Visible en el documento impreso)</small></label>
          <div class="col-sm-8">
            <textarea  class="form-control form-control-sm min_max_100" name="notas">{{old('notas')}}</textarea>
          </div>
        </div>

      </div>
      <div class="col-md-6 offset-md-1">
        <div class="form-group row">
          <label class="col-sm-4 col-form-label">Número de factura</label>
          <div class="col-sm-8">
            <input type="text" class="form-control"  id="codigo" name="codigo" value="{{$codigoFactura}}" >
          </div>
        </div>
        <div class="form-group row">
          <label class="col-sm-4 col-form-label">Fecha <span class="text-danger">*</span></label>
          <div class="col-sm-8">
            <input type="text" class="form-control datepicker"  id="fecha" value="{{date('d-m-Y')}}" name="fecha" disabled=""  >
          </div>
        </div>
        <div class="form-group row">
          <label class="col-sm-4 col-form-label">Fecha de <br> Vencimiento <span class="text-danger">*</span></label>
          <div class="col-sm-8">
            <input type="text" class="form-control" id="vencimiento" value="{{date('d-m-Y')}}" name="vencimiento" disabled="">
          </div>
        </div>
        <div class="form-group row">
          <label class="col-sm-4 col-form-label">Bodega <span class="text-danger">*</span></label>
          <div class="col-sm-8">
            <select name="bodega" id="bodega" class="form-control"  required="">
              @foreach($bodegas as $bodega)  
                <option value="{{$bodega->id}}" {{old('bodega')==$bodega->id?'selected':''}}>{{$bodega->bodega}}</option>
              @endforeach
            </select>
          </div>
        </div>
      </div>
    </div>


      <!-- Desgloce -->
    <div class="row">
      <div class="col-md-12 fact-table">
        <table class="table table-striped table-sm" id="table-form" width="100%">
          <thead class="thead-dark">
            <th width="28%">Categoría/Ítem</th>
            <th width="8%">Precio</th>
            <th width="5%">Desc %</th>
            <th width="12%">Impuesto</th>
            <th width="13%">Descripción</th>
            <th width="7%">Cantidad</th>
            <th width="10%">Total</th>
            <th width="2%"></th>
          </thead>
          <tbody>
            <tr id="1">                          
              <td  class="no-padding">
               @if($producto) <input type="hidden" id="producto_inv" value="true">   @endif
                <select class="form-control form-control-sm selectpicker no-padding"  title="Seleccione" data-live-search="true" data-size="5" name="item[]" id="item1" onchange="rellenar(1, this.value);" required="">
                <optgroup label="Ítems">
                @foreach($inventario as $item)
                <option value="{{$item->id}}" @if($producto) {{$producto->id==$item->id?'selected':''}}  @endif >{{$item->producto}} - ({{$item->ref}})</option>
                 @endforeach
                </optgroup>
                @foreach($categorias as $categoria)
                <optgroup label="{{$categoria->nombre}}">
                    @foreach($categoria->hijos(true) as $categoria1)
                      <option {{old('categoria')==$categoria1->id?'selected':''}} value="cat_{{$categoria1->id}}" {{$categoria1->estatus==0?'disabled':''}}>{{$categoria1->nombre}}</option>
                      @foreach($categoria1->hijos(true) as $categoria2)
                          <option class="hijo" {{old('categoria')==$categoria2->id?'selected':''}} value="cat_{{$categoria2->id}}" {{$categoria2->estatus==0?'disabled':''}}>{{$categoria2->nombre}}</option>
                        @foreach($categoria2->hijos(true) as $categoria3)
                          <option class="nieto" {{old('categoria')==$categoria3->id?'selected':''}} value="cat_{{$categoria3->id}}" {{$categoria3->estatus==0?'disabled':''}}>{{$categoria3->nombre}}</option>
                          @foreach($categoria3->hijos(true) as $categoria4)
                            <option class="bisnieto" {{old('categoria')==$categoria4->id?'selected':''}} value="cat_{{$categoria4->id}}" {{$categoria3->estatus==0?'disabled':''}}>{{$categoria4->nombre}}</option>
                          @endforeach

                        @endforeach

                      @endforeach
                    @endforeach
                  </optgroup>
                  @endforeach
                </select>
              </td>
              <td class="monetario">
                <input type="number" class="form-control form-control-sm" id="precio1" name="precio[]" placeholder="Precio Unitario" onkeyup="total(1)" required="">
              </td>
              <td>
                <input type="text" class="form-control form-control-sm nro" id="desc1" name="desc[]" placeholder="%" onkeyup="total(1)" >
              </td>
              <td>        
                <select class="form-control form-control-sm selectpicker" name="impuesto[]" id="impuesto1" title="Impuesto" onchange="totalall();" required="">
                  @foreach($impuestos as $impuesto)
                    <option value="{{$impuesto->id}}" porc="{{$impuesto->porcentaje}}">{{$impuesto->nombre}} - {{$impuesto->porcentaje}}%</option>
                  @endforeach
                </select>
              </td>
              <td  style="padding-top: 1% !important;">                           
                <textarea  class="form-control form-control-sm" id="descripcion1" name="descripcion[]" placeholder="Descripción" ></textarea>
              </td>
              <td width="5%">
                <input type="number" class="form-control form-control-sm" id="cant1" name="cant[]" placeholder="Cantidad" onchange="total(1);" min="1" required="">
              </td>
              <td>
                <input type="text" class="form-control form-control-sm text-right" id="total1" value="0" disabled="">
              </td>
              <td><button type="button" class="btn btn-outline-secondary btn-icons" onclick="Eliminar(1);">X</button></td>
            </tr>
          </tbody>
        </table>
          <p class="text-left nomargin">
              <a href="{{route('inventario.create')}}"
                 data-toggle="modal" data-target="#myModal2">
                  <i class="fas fa-plus"></i> Nuevo producto
              </a>
          </p>
        <div class="alert alert-danger" style="display: none;" id="error-items"></div>
      </div>
    </div>

    <button class="btn btn-outline-primary" onclick="createRow();" type="button" style="margin-top: 5%">Agregar línea</button><a><i data-tippy-content="Agrega nuevas lineas haciendo <a href='#'>clíck aquí</a>" class="icono far fa-question-circle"></i></a>
    <div class="row"  style="margin-top: 10%;">
          <div class="col-md-7 no-padding">
        <h5>RETENCIONES</h5>
            <table class="table table-striped table-sm" id="table-retencion">
              <thead class="thead-dark">
                <th width="60%">Tipo de Retención</th>
                <th width="34%">Valor</th>
                <th width="5%"></th>
              </thead>
              <tbody>
              </tbody>
            </table>
            <button class="btn btn-outline-primary" onclick="CrearFilaRetencion();" type="button" style="margin-top: 2%;">Agregar Retención</button><a><i data-tippy-content="Agrega nuevas retenciones haciendo <a href='#'>clíck aquí</a>" class="icono far fa-question-circle"></i></a>
          </div>
    </div>
    <!-- Totales 
            
          </tr> -->
     <!-- Totales -->
    <div class="row" style="margin-top: 10%;">
      <div class="col-md-4 offset-md-8">
        <table class="text-right widthtotal" >
          <tr>
            <td width="40%">Subtotal</td>
            <td>{{Auth::user()->empresa()->moneda}} <span id="subtotal">0</span></td>
            <input type="hidden" id="subtotal_categoria_js" value="0">
          </tr>
          <tr>
            <td>Descuento</td><td id="descuento">{{Auth::user()->empresa()->moneda}} 0</td>
          </tr>
        </table>

        <table  class="text-right widthtotal"  id="totalesreten" style="width: 100%">
          <tbody></tbody>
        </table> 
        <table class="text-right widthtotal"  style="width: 100%" id="totales">         
          <tr>
            <td width="40%">Subtotal</td>
            <td>{{Auth::user()->empresa()->moneda}} <span id="subsub">0</span></td>
          </tr>
        </table>
        <hr>
        <table class="text-right widthtotal" style="font-size: 24px !important;">
          <tr>
            <td width="40%">TOTAL</td>
            <td>{{Auth::user()->empresa()->moneda}} <span id="total">0</span></td>
          </tr>
        </table>
      </div>
    </div>
      <hr>
      <div class="row" >
        
        <div class="col-sm-12" style="text-align: right;  padding-top: 1%;">
          
          <a href="{{route('facturasp.index')}}" class="btn btn-outline-secondary">Cancelar</a>
          <button type="submit" class="btn btn-success">Guardar</button>
        </div>
      </div>


    </form>
  <input type="hidden" id="impuestos" value="{{json_encode($impuestos)}}">
  <input type="hidden" id="allproductos" value="{{json_encode($inventario)}}">
  <input type="hidden" id="url" value="{{url('/')}}">
  <input type="hidden" id="jsonproduc" value="{{route('inventario.all')}}">
  <input type="hidden" id="simbolo" value="{{Auth::user()->empresa()->moneda}}">

  <input type="hidden" id="allcategorias" value='@foreach($categorias as $categoria)
                            <optgroup label="{{$categoria->nombre}}">
                                @foreach($categoria->hijos(true) as $categoria1)
                                  <option {{old('categoria')==$categoria1->id?'selected':''}} value="cat_{{$categoria1->id}}" {{$categoria1->estatus==0?'disabled':''}}>{{$categoria1->nombre}}</option>
                                  @foreach($categoria1->hijos(true) as $categoria2)
                                      <option class="hijo" {{old('categoria')==$categoria2->id?'selected':''}} value="cat_{{$categoria2->id}}" {{$categoria2->estatus==0?'disabled':''}}>{{$categoria2->nombre}}</option>
                                    @foreach($categoria2->hijos(true) as $categoria3)
                                      <option class="nieto" {{old('categoria')==$categoria3->id?'selected':''}} value="cat_{{$categoria3->id}}" {{$categoria3->estatus==0?'disabled':''}}>{{$categoria3->nombre}}</option>
                                      @foreach($categoria3->hijos(true) as $categoria4)
                                        <option class="bisnieto" {{old('categoria')==$categoria4->id?'selected':''}} value="cat_{{$categoria4->id}}" {{$categoria3->estatus==0?'disabled':''}}>{{$categoria4->nombre}}</option>

                                      @endforeach

                                    @endforeach

                                  @endforeach
                                @endforeach
                            </optgroup>
                          @endforeach'>
  <input type="hidden" id="retenciones" value="{{json_encode($retenciones)}}">
  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title"></h4>
        </div>
        <div class="modal-body">
          	<form method="POST" action="{{ route('contactos.store') }}" style="padding: 2% 3%;" role="form" class="forms-sample" novalidate id="form-contacto">
  		{{ csrf_field() }}
  		<div class="row">
  			<div class="form-group col-md-3">
	  			<label class="control-label">Tipo de Identificación <span class="text-danger">*</span></label>
	  			<select class="form-control selectpicker" name="tip_iden" id="tip_iden" required="" title="Seleccione">
	  				@foreach($identificaciones as $identificacion)
                  		<option {{old('tip_iden')==$identificacion->id?'selected':''}} value="{{$identificacion->id}}" title="{{$identificacion->mini()}}">{{$identificacion->identificacion}}</option>
	  				@endforeach
                </select>
				<span class="help-block error">
		        	<strong>{{ $errors->first('tip_iden') }}</strong>
		        </span>
			</div>
			<div class="form-group col-md-3">
	  			<label class="control-label">Identificación <span class="text-danger">*</span><a><i data-tippy-content="Identificación de la persona" class="icono far fa-question-circle"></i></a></label>
				<input type="text" class="form-control" name="nit" id="nit" required="" maxlength="20" value="{{old('nit')}}">
				<span class="help-block error">
					<strong>{{ $errors->first('nit') }}</strong>
				</span>
			</div>

			<div class="form-group col-md-6">
	  			<label class="control-label">Nombre <span class="text-danger">*</span></label>
				<input type="text" class="form-control" name="nombre" id="nombre" required="" maxlength="200" value="{{old('nombre')}}">
				<span class="help-block error">
		        	<strong>{{ $errors->first('nombre') }}</strong>
		        </span>
			</div>
  		</div> 
  		<div class="row">
  			<div class="form-group col-md-5">
	  			<label class="control-label">Dirección </label>
	  			<textarea class="form-control" name="direccion" >{{old('direccion')}}</textarea>
				<span class="help-block error">
					<strong>{{ $errors->first('direccion') }}</strong>
				</span>
			</div>
			<div class="form-group col-md-3">
	  			<label class="control-label">Ciudad</label>
				<input type="text" class="form-control" id="ciudad" name="ciudad" maxlength="200"  value="{{old('ciudad')}}">
				<span class="help-block error">
					<strong>{{ $errors->first('ciudad') }}</strong>
				</span>
			</div>
			<div class="form-group col-md-4">
	  			<label class="control-label" for="email">Correo Electrónico</label>
				<input type="email" class="form-control" id="email" name="email" data-error="Dirección de correo electrónico invalida" maxlength="100"  value="{{old('email')}}">
				<div class="help-block error with-errors"></div>
				<span class="help-block error">
					<strong>{{ $errors->first('email') }}</strong>
				</span>
			</div>
			


  		</div>
  		<div class="row">
  			<div class="form-group col-md-3">
	  			<label class="control-label">Teléfono  <span class="text-danger">*</span></label>
	  			<div class="row">
	  				<div class="col-md-4 nopadding ">
	  					<select class="form-control selectpicker prefijo" name="pref1" id="pref1" required="" title="Seleccione" data-size="5" data-live-search="true">
			  				@foreach($prefijos as $prefijo)
		                  		<option @if(old('pref1')) {{old('pref1')==$prefijo->phone_code?'selected':''}} @else {{'+'.$prefijo->phone_code==Auth::user()->empresa()->codigo?'selected':''}}  @endif

		                  		 	data-icon="flag-icon flag-icon-{{strtolower($prefijo->iso2)}}"

		                  		 value="+{{$prefijo->phone_code}}" title="+{{$prefijo->phone_code}}" data-subtext="+{{$prefijo->phone_code}}">{{$prefijo->nombre}}</option>
			  				@endforeach
		                </select>

				
	  				</div>
	  				<div class="col-md-8" style="padding-left:0;">
	  					<input type="text" class="form-control" id="telefono1" name="telefono1" required="" maxlength="15" value="{{old('telefono1')}}">
	  				</div>
	  			</div>
				<span class="help-block error">
		        	<strong>{{ $errors->first('telefono1') }}</strong>
		        </span>
			</div>
  			<div class="form-group col-md-3">
	  			<label class="control-label">Teléfono 2</label>
  				<div class="row">
  					<div class="col-md-4 nopadding ">
	  					<select class="form-control selectpicker prefijo" name="pref2" id="pref2" title="Seleccione" data-size="5" data-live-search="true">
			  				@foreach($prefijos as $prefijo)
		                  		<option @if(old('pref2')) {{old('pref2')==$prefijo->phone_code?'selected':''}} @else {{'+'.$prefijo->phone_code==Auth::user()->empresa()->codigo?'selected':''}}  @endif

		                  		 	data-icon="flag-icon flag-icon-{{strtolower($prefijo->iso2)}}"

		                  		 value="+{{$prefijo->phone_code}}" title="+{{$prefijo->phone_code}}" data-subtext="+{{$prefijo->phone_code}}">{{$prefijo->nombre}}</option>
			  				@endforeach
		                </select>
	  				</div>
	  				<div class="col-md-8" style="padding-left:0;">
	  					<input type="text" class="form-control" id="telefono2" name="telefono2" maxlength="15" value="{{old('telefono2')}}">
	  				</div>
  				</div>
				<span class="help-block error">
		        	<strong>{{ $errors->first('telefono2') }}</strong>
		        </span>
			</div>
			<div class="form-group col-md-3">
	  			<label class="control-label">Fax</label>
					<div class="row">
						<div class="col-md-4 nopadding ">
		  					<select class="form-control selectpicker prefijo" name="preffax" id="preffax" title="Seleccione" data-size="5" data-live-search="true">
				  				@foreach($prefijos as $prefijo)
			                  		<option @if(old('preffax')) {{old('preffax')==$prefijo->phone_code?'selected':''}} @else {{'+'.$prefijo->phone_code==Auth::user()->empresa()->codigo?'selected':''}}  @endif

			                  		 	data-icon="flag-icon flag-icon-{{strtolower($prefijo->iso2)}}"

			                  		 value="+{{$prefijo->phone_code}}" title="+{{$prefijo->phone_code}}" data-subtext="+{{$prefijo->phone_code}}">{{$prefijo->nombre}}</option>
				  				@endforeach
			                </select>
		  				</div>
		  				<div class="col-md-8" style="padding-left:0;">
		  					<input type="text" class="form-control" id="fax" name="fax"  maxlength="15" value="{{old('fax')}}">
		  				</div>
					</div>
					<span class="help-block error">
			        	<strong>{{ $errors->first('fax') }}</strong>
			        </span>
			</div>
			<div class="form-group col-md-3">
	  			<label class="control-label">Celular</label>
	  			<div class="row">
	  				<div class="col-md-4 nopadding ">
	  					<select class="form-control selectpicker prefijo" name="prefcelular" id="prefcelular" title="Seleccione" data-size="5" data-live-search="true">
			  				@foreach($prefijos as $prefijo)
		                  		<option @if(old('prefcelular')) {{old('prefcelular')==$prefijo->phone_code?'selected':''}} @else {{'+'.$prefijo->phone_code==Auth::user()->empresa()->codigo?'selected':''}}  @endif

		                  		 	data-icon="flag-icon flag-icon-{{strtolower($prefijo->iso2)}}"

		                  		 value="+{{$prefijo->phone_code}}" title="+{{$prefijo->phone_code}}" data-subtext="+{{$prefijo->phone_code}}">{{$prefijo->nombre}}</option>
			  				@endforeach
		                </select>
	  				</div>
	  				<div class="col-md-8" style="padding-left:0;">
	  					<input type="text" class="form-control" id="celular" name="celular" maxlength="15" value="{{old('celular')}}">
	  				</div>
	  			</div>
				
				<span class="help-block error">
		        	<strong>{{ $errors->first('celular') }}</strong>
		        </span>
			</div>
			
			
			
  		</div>
  		<div class="row">
			<div class="form-group col-md-3">
	  			<label class="control-label">Tipo de Contacto  <span class="text-danger">*</span></label>
				<div class="form-check form-check-flat">
                    <label class="form-check-label">
                      <input type="checkbox" class="form-check-input" name="contacto[]" value="0"> Cliente
                    <i class="input-helper"></i></label>
                  </div>
                  <div class="form-check form-check-flat">
                    <label class="form-check-label">
                      <input type="checkbox" class="form-check-input" name="contacto[]" value="1" > Proveedor
                    <i class="input-helper"></i></label>
                  </div>
                  <span class="help-block error">
					<strong>{{ $errors->first('contacto') }}</strong>
				</span>
			</div>

  			<div class="form-group col-md-3">
	  			<label class="control-label">Tipo de Empresa <span class="text-danger">*</span><a><i data-tippy-content="Tipo empresa a la que pertenece el contacto" class="icono far fa-question-circle"></i></a></label>
	  			<select class="form-control selectpicker" name="tipo_empresa" id="tipo_empresa" required="" title="Seleccione" data-live-search="true" data-size="5">
	  				@foreach($tipos_empresa as $tipo_empresa)
                  		<option {{old('tipo_empresa')==$tipo_empresa->id?'selected':''}} value="{{$tipo_empresa->id}}">{{$tipo_empresa->nombre}}</option>
	  				@endforeach
                </select>
                <p class="text-left nomargin"> <a href="{{route('tiposempresa.create')}}" target="_blanck"><i class="fas fa-plus"></i> Nuevo Tipo de Empresa</a></p>
				<span class="help-block error">
		        	<strong>{{ $errors->first('tipo_empresa') }}</strong>
		        </span>
			</div>

  			<div class="form-group col-md-3">
  				<label class="control-label">Lista de Precios <a><i data-tippy-content="Lista de precios que desee asociar a este contacto" class="icono far fa-question-circle"></i></a></label>
  				<select class="form-control selectpicker" name="lista_precio" id="lista_precio" title="Seleccione" data-size="5">
  					
	  				@foreach($listas as $lista)
                  		<option {{old('lista_precio')==$lista->id?'selected':''}} value="{{$lista->id}}">{{$lista->nombre()}}</option>
	  				@endforeach
                </select>
  			</div>
  			<div class="form-group col-md-3">
  				<label class="control-label">Vendedor <a><i data-tippy-content="Vendedor que desee asociar a este contacto" class="icono far fa-question-circle"></i></a></label>
  				<select class="form-control selectpicker" name="vendedor" id="vendedor" title="Seleccione" data-live-search="true" data-size="5">
	  				@foreach($vendedores as $vendedor)
                  		<option {{old('vendedor')==$vendedor->id?'selected':''}} value="{{$vendedor->id}}">{{$vendedor->nombre}}</option>
	  				@endforeach
                </select>
  			</div>	
  		</div>
  		<div class="row">
  			<div class="form-group col-md-12">
	  			<label class="control-label">Observaciones</label>

	  			<textarea class="form-control" name="observaciones" >{{old('observaciones')}}</textarea>
				<span class="help-block error">
					<strong>{{ $errors->first('observaciones') }}</strong>
				</span>
			</div>
  		</div>
		<small>Los campos marcados con <span class="text-danger">*</span> son obligatorios</small>
		<div class="row" style="margin-top: 2%;">
  			<div class="col-md-12">

				<h4 class="card-title">Personas Asociadas</h4>
                <table class="table table-sm table-striped" id="table-form-contacto" width="100%">
                	<thead class="thead-dark"> 
                		<tr>
							<th width="27%">Nombre	y Apellido</th>
							<th width="28%">Correo Electrónico</th>
							<th width="15%">Teléfono</th>
							<th width="15%">Celular</th>
							<th width="10%">Enviar Notificaciones <a><i data-tippy-content="Marque 'si' cuando desee que esta persona reciba correos con facturas disponibles o vencidas"  class="icono far fa-question-circle"></i></a></th>
							<th width="5%"></th>
                		</tr>
                	</thead>
                	<tbody>
                	</tbody>

                </table>
                <button class="btn btn-outline-primary" onclick="createRowContato();" type="button" >Asociar Persona</button><a><i data-tippy-content="En caso de ser una empresa, personas pertenecientes" class="icono far fa-question-circle"></a></i>
                
            </div>
        </div>    
  		<hr>
  		<div class="row" style="text-align: right;">
  			<div class="col-md-12">
				<a href="{{route('empresas.index')}}" class="btn btn-outline-light" >Cancelar</a>
  				<button type="submit" class="btn btn-success">Guardar</button>
  			</div>
  		</div>
  	</form>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>

  <div class="modal fade" id="myModal2" role="dialog">
      <div class="modal-dialog modal-lg">
          <div class="modal-content">
              <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <h4 class="modal-title"></h4>
              </div>
              <div class="modal-body">
                @include('inventario.modal.create')
              </div>
              <div class="modal-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              </div>
          </div>
      </div>
  </div>

  <script
      src="https://code.jquery.com/jquery-3.3.1.min.js"
      integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
      crossorigin="anonymous"></script>
  <script>

      $(document).ready(function(){

          let lastRegis = new URLSearchParams(window.location.search);

          if(lastRegis.has('pro')){

              let idPro     = lastRegis.get('pro');
              let impuesto  = $('#impuestosId').val();

              setTimeout(function () {
                  $('#item1').val(idPro).change();
                  $('#impuesto1').val(impuesto).change();
                  clearTimeout(this);
              }, 1000);

          }
      });



  </script>

@endsection

